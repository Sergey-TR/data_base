create database example;
create table users (
id int,
name varchar(45)
);